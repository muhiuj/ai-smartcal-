"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Calendar,
  Clock,
  Zap,
  Target,
  Download,
  Plus,
  Upload,
  Sparkles,
  TrendingUp,
  Brain,
  AlertTriangle,
  X,
  ArrowRight,
  CheckCircle,
  Play,
  RotateCcw,
} from "lucide-react"

interface Task {
  id: string
  name: string
  duration: number // in hours
  energy: "Creative" | "Task-Oriented" | "Low-Energy"
  priority: "High" | "Medium" | "Low"
  completed?: boolean
}

interface TimeSlot {
  day: string
  time: string
  isWorkTime?: boolean
  scheduledTask?: string
  energyLevel: number
  energyType: "Creative" | "Task-Oriented" | "Low-Energy"
}

interface Recommendation {
  taskId: string
  day: string
  time: string
  confidence: number
  reason: string
}

interface OnboardingStep {
  id: string
  title: string
  description: string
  target: string
  position: "top" | "bottom" | "left" | "right"
}

export function SmartBusinessPlanner() {
  const [isDemoMode, setIsDemoMode] = useState(true)
  const [showOnboarding, setShowOnboarding] = useState(true)
  const [currentOnboardingStep, setCurrentOnboardingStep] = useState(0)
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false)
  const [completedActions, setCompletedActions] = useState<Set<string>>(new Set())

  const [energyLevels, setEnergyLevels] = useState<Record<string, number>>(
    isDemoMode
      ? {
          "monday-9:00": 80,
          "monday-10:00": 85,
          "monday-11:00": 75,
          "monday-14:00": 70,
          "monday-15:00": 65,
          "monday-19:00": 40,
          "tuesday-9:00": 75,
          "tuesday-10:00": 80,
          "tuesday-19:00": 45,
          "wednesday-9:00": 70,
          "wednesday-10:00": 75,
          "wednesday-19:00": 50,
          "thursday-9:00": 85,
          "thursday-10:00": 90,
          "thursday-19:00": 35,
          "friday-9:00": 60,
          "friday-10:00": 65,
          "friday-19:00": 55,
          "saturday-10:00": 90,
          "saturday-11:00": 95,
          "saturday-14:00": 80,
          "sunday-10:00": 85,
          "sunday-11:00": 80,
          "sunday-19:00": 60,
        }
      : {},
  )

  const [energyTypes, setEnergyTypes] = useState<Record<string, string>>(
    isDemoMode
      ? {
          "monday-9:00": "Creative",
          "monday-10:00": "Creative",
          "monday-11:00": "Creative",
          "monday-14:00": "Task-Oriented",
          "monday-15:00": "Task-Oriented",
          "monday-19:00": "Low-Energy",
          "tuesday-9:00": "Creative",
          "tuesday-10:00": "Creative",
          "tuesday-19:00": "Low-Energy",
          "wednesday-9:00": "Task-Oriented",
          "wednesday-10:00": "Task-Oriented",
          "wednesday-19:00": "Low-Energy",
          "thursday-9:00": "Creative",
          "thursday-10:00": "Creative",
          "thursday-19:00": "Low-Energy",
          "friday-9:00": "Task-Oriented",
          "friday-10:00": "Task-Oriented",
          "friday-19:00": "Low-Energy",
          "saturday-10:00": "Creative",
          "saturday-11:00": "Creative",
          "saturday-14:00": "Task-Oriented",
          "sunday-10:00": "Creative",
          "sunday-11:00": "Creative",
          "sunday-19:00": "Low-Energy",
        }
      : {},
  )

  const [workBlocks, setWorkBlocks] = useState<Record<string, boolean>>(
    isDemoMode
      ? {
          "monday-9:00": true,
          "monday-10:00": true,
          "monday-11:00": true,
          "monday-12:00": true,
          "monday-13:00": true,
          "monday-14:00": true,
          "monday-15:00": true,
          "monday-16:00": true,
          "monday-17:00": true,
          "tuesday-9:00": true,
          "tuesday-10:00": true,
          "tuesday-11:00": true,
          "tuesday-12:00": true,
          "tuesday-13:00": true,
          "tuesday-14:00": true,
          "tuesday-15:00": true,
          "tuesday-16:00": true,
          "tuesday-17:00": true,
          "wednesday-9:00": true,
          "wednesday-10:00": true,
          "wednesday-11:00": true,
          "wednesday-12:00": true,
          "wednesday-13:00": true,
          "wednesday-14:00": true,
          "wednesday-15:00": true,
          "wednesday-16:00": true,
          "wednesday-17:00": true,
          "thursday-9:00": true,
          "thursday-10:00": true,
          "thursday-11:00": true,
          "thursday-12:00": true,
          "thursday-13:00": true,
          "thursday-14:00": true,
          "thursday-15:00": true,
          "thursday-16:00": true,
          "thursday-17:00": true,
          "friday-9:00": true,
          "friday-10:00": true,
          "friday-11:00": true,
          "friday-12:00": true,
          "friday-13:00": true,
          "friday-14:00": true,
          "friday-15:00": true,
          "friday-16:00": true,
          "friday-17:00": true,
        }
      : {},
  )

  const [selectedDay, setSelectedDay] = useState("monday")
  const [scheduledTasks, setScheduledTasks] = useState<Record<string, string>>({})
  const [showRecommendations, setShowRecommendations] = useState(false)

  const onboardingSteps: OnboardingStep[] = [
    {
      id: "welcome",
      title: "Welcome to Smart Business Planner! 🎉",
      description:
        "Let's take a quick tour to show you how to optimize your side business schedule around your work life.",
      target: "header",
      position: "bottom",
    },
    {
      id: "work-schedule",
      title: "Step 1: Set Your Work Schedule",
      description:
        "We've pre-loaded a sample work schedule. In real use, paste your calendar events or upload a .csv/.ics file here.",
      target: "work-schedule",
      position: "right",
    },
    {
      id: "energy-profile",
      title: "Step 2: Define Your Energy Levels",
      description:
        "Adjust the sliders to match your energy throughout the day. We've set up a realistic example for you to explore.",
      target: "energy-profile",
      position: "right",
    },
    {
      id: "business-tasks",
      title: "Step 3: Add Your Business Tasks",
      description:
        "These are sample tasks for a content creator. You can add, edit, or remove tasks based on your business needs.",
      target: "business-tasks",
      position: "right",
    },
    {
      id: "calendar-view",
      title: "Step 4: Your Optimized Calendar",
      description: "This heatmap shows your energy levels throughout the week. Scheduled tasks appear as blue blocks.",
      target: "calendar-view",
      position: "left",
    },
    {
      id: "recommendations",
      title: "Step 5: Smart Recommendations",
      description:
        "Click 'Show' to see AI-powered suggestions for when to schedule your tasks based on your energy patterns.",
      target: "recommendations",
      position: "left",
    },
    {
      id: "auto-optimize",
      title: "Step 6: One-Click Optimization",
      description: "Click this button to automatically schedule all your tasks at optimal times. Try it now!",
      target: "auto-optimize",
      position: "bottom",
    },
  ]

  const timeSlots = Array.from({ length: 16 }, (_, i) => {
    const hour = i + 6
    return `${hour}:00`
  })

  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

  const [businessTasks, setBusinessTasks] = useState<Task[]>([
    { id: "1", name: "Content Writing", duration: 2, energy: "Creative", priority: "High" },
    { id: "2", name: "Video Filming", duration: 3, energy: "Creative", priority: "High" },
    { id: "3", name: "Website Building", duration: 4, energy: "Task-Oriented", priority: "Medium" },
    { id: "4", name: "Social Media", duration: 1, energy: "Low-Energy", priority: "Medium" },
    { id: "5", name: "Learning", duration: 2, energy: "Task-Oriented", priority: "Low" },
    { id: "6", name: "Email Marketing", duration: 1, energy: "Low-Energy", priority: "Medium" },
    { id: "7", name: "Client Calls", duration: 1, energy: "Task-Oriented", priority: "High" },
  ])

  const triggerSuccess = (action: string) => {
    setCompletedActions((prev) => new Set([...prev, action]))
    setShowSuccessAnimation(true)
    setTimeout(() => setShowSuccessAnimation(false), 2000)
  }

  const optimizeSchedule = () => {
    const newSchedule: Record<string, string> = {}
    const sortedTasks = [...businessTasks].sort((a, b) => {
      const priorityWeight = { High: 3, Medium: 2, Low: 1 }
      return priorityWeight[b.priority] - priorityWeight[a.priority]
    })

    sortedTasks.forEach((task) => {
      const recommendation = generateRecommendations.find((r) => r.taskId === task.id)
      if (recommendation) {
        const slotKey = `${recommendation.day.toLowerCase()}-${recommendation.time}`
        newSchedule[task.id] = slotKey
      }
    })

    setScheduledTasks(newSchedule)
    triggerSuccess("optimize")

    if (currentOnboardingStep === 6) {
      setTimeout(() => setCurrentOnboardingStep(7), 1000)
    }
  }

  const startFresh = () => {
    setIsDemoMode(false)
    setEnergyLevels({})
    setEnergyTypes({})
    setWorkBlocks({})
    setScheduledTasks({})
    setShowOnboarding(false)
    setCompletedActions(new Set())
  }

  const generateRecommendations = useMemo((): Recommendation[] => {
    const recommendations: Recommendation[] = []

    businessTasks.forEach((task) => {
      if (scheduledTasks[task.id]) return // Skip already scheduled tasks

      let bestSlot = { day: "", time: "", confidence: 0, reason: "" }

      days.forEach((day) => {
        timeSlots.forEach((time) => {
          const slotKey = `${day.toLowerCase()}-${time}`
          const energyLevel = energyLevels[slotKey] || 50
          const energyType = energyTypes[slotKey] || "Task-Oriented"
          const isWorkTime = workBlocks[slotKey]
          const isOccupied = Object.values(scheduledTasks).includes(slotKey)

          if (isWorkTime || isOccupied) return

          let confidence = 0
          let reason = ""

          // Energy level matching (40% weight)
          if (task.energy === "Creative" && energyLevel >= 70) {
            confidence += 40
            reason = "High energy perfect for creative work"
          } else if (task.energy === "Task-Oriented" && energyLevel >= 50) {
            confidence += 35
            reason = "Good energy for focused tasks"
          } else if (task.energy === "Low-Energy" && energyLevel >= 30) {
            confidence += 30
            reason = "Suitable for low-energy activities"
          }

          // Energy type matching (30% weight)
          if (energyType === task.energy) {
            confidence += 30
          }

          // Priority bonus (20% weight)
          if (task.priority === "High") confidence += 20
          else if (task.priority === "Medium") confidence += 10

          // Time of day preferences (10% weight)
          const hour = Number.parseInt(time.split(":")[0])
          if (task.energy === "Creative" && hour >= 9 && hour <= 11) confidence += 10
          else if (task.energy === "Task-Oriented" && hour >= 14 && hour <= 17) confidence += 10
          else if (task.energy === "Low-Energy" && (hour >= 19 || hour <= 8)) confidence += 10

          if (confidence > bestSlot.confidence) {
            bestSlot = { day, time, confidence, reason }
          }
        })
      })

      if (bestSlot.confidence > 30) {
        recommendations.push({
          taskId: task.id,
          day: bestSlot.day,
          time: bestSlot.time,
          confidence: bestSlot.confidence,
          reason: bestSlot.reason,
        })
      }
    })

    return recommendations.sort((a, b) => b.confidence - a.confidence).slice(0, 5)
  }, [businessTasks, energyLevels, energyTypes, scheduledTasks, workBlocks])

  const conflicts = useMemo(() => {
    const conflictList: string[] = []

    Object.entries(scheduledTasks).forEach(([taskId, slotKey]) => {
      const task = businessTasks.find((t) => t.id === taskId)
      if (!task) return

      const [day, time] = slotKey.split("-")
      const energyLevel = energyLevels[slotKey] || 50
      const isWorkTime = workBlocks[slotKey]

      if (isWorkTime) {
        conflictList.push(`${task.name} conflicts with work time`)
      }

      if (task.energy === "Creative" && energyLevel < 60) {
        conflictList.push(`${task.name} needs higher energy (${energyLevel}% current)`)
      }

      if (task.energy === "Task-Oriented" && energyLevel < 40) {
        conflictList.push(`${task.name} needs more energy (${energyLevel}% current)`)
      }
    })

    return conflictList
  }, [scheduledTasks, businessTasks, energyLevels, workBlocks])

  const getEnergyHeatmapColor = (day: string, time: string) => {
    const slotKey = `${day.toLowerCase()}-${time}`
    const energyLevel = energyLevels[slotKey] || 50
    const isWorkTime = workBlocks[slotKey]
    const isScheduled = Object.values(scheduledTasks).includes(slotKey)

    if (isWorkTime) return "bg-gray-400/30"
    if (isScheduled) return "bg-primary/60"

    if (energyLevel >= 80) return "bg-green-500/40"
    if (energyLevel >= 60) return "bg-yellow-500/40"
    if (energyLevel >= 40) return "bg-orange-500/40"
    return "bg-red-500/30"
  }

  return (
    <div className="min-h-screen bg-background p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5 pointer-events-none" />

      {showSuccessAnimation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
          <div className="bg-green-500/90 backdrop-blur-xl rounded-full p-8 animate-bounce">
            <CheckCircle className="h-16 w-16 text-white" />
          </div>
        </div>
      )}

      {showOnboarding && currentOnboardingStep < onboardingSteps.length && (
        <div className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-card/95 backdrop-blur-xl border border-white/20 rounded-2xl p-6 max-w-md shadow-2xl">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Sparkles className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{onboardingSteps[currentOnboardingStep].title}</h3>
                  <div className="text-sm text-muted-foreground">
                    Step {currentOnboardingStep + 1} of {onboardingSteps.length}
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowOnboarding(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <p className="text-muted-foreground mb-6 leading-relaxed">
              {onboardingSteps[currentOnboardingStep].description}
            </p>

            <div className="flex items-center justify-between">
              <div className="flex gap-1">
                {onboardingSteps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentOnboardingStep ? "bg-primary" : "bg-muted"
                    }`}
                  />
                ))}
              </div>

              <div className="flex gap-2">
                {currentOnboardingStep > 0 && (
                  <Button variant="outline" size="sm" onClick={() => setCurrentOnboardingStep((prev) => prev - 1)}>
                    Back
                  </Button>
                )}
                <Button
                  size="sm"
                  onClick={() => {
                    if (currentOnboardingStep === onboardingSteps.length - 1) {
                      setShowOnboarding(false)
                    } else {
                      setCurrentOnboardingStep((prev) => prev + 1)
                    }
                  }}
                  className="bg-gradient-to-r from-primary to-accent text-white"
                >
                  {currentOnboardingStep === onboardingSteps.length - 1 ? "Get Started" : "Next"}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="mx-auto max-w-7xl relative z-10">
        <div id="header" className="mb-12 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Planning</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent leading-tight">
            Smart Business Planner
          </h1>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto leading-relaxed">
            Optimize your side business schedule around your work life with intelligent energy matching
          </p>

          {isDemoMode && (
            <div className="flex items-center justify-center gap-4 mt-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
                <Play className="h-4 w-4 text-accent" />
                <span className="text-sm font-medium text-accent">Demo Mode - Sample Data Loaded</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={startFresh}
                className="bg-transparent backdrop-blur-xl border-white/10 hover:bg-primary/10"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Start Fresh
              </Button>
              {!showOnboarding && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setShowOnboarding(true)
                    setCurrentOnboardingStep(0)
                  }}
                  className="bg-transparent backdrop-blur-xl border-white/10 hover:bg-primary/10"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Show Tour
                </Button>
              )}
            </div>
          )}
        </div>

        {/* 3-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Sidebar - Setup (30%) */}
          <div className="lg:col-span-4 space-y-6">
            <Card className="bg-card/80 backdrop-blur-xl border-white/10 p-6 transition-all duration-300 hover:shadow-xl hover:border-primary/20">
              <div className="mb-6 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10 shadow-lg shadow-primary/20">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-xl font-semibold">Setup Your Week</h2>
              </div>

              {/* Work Schedule Input */}
              <div className="space-y-6">
                <div id="work-schedule" className="space-y-3">
                  <Label htmlFor="calendar-input" className="text-sm font-medium flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-accent" />
                    Work Schedule
                    {completedActions.has("work-schedule") && <CheckCircle className="h-4 w-4 text-green-500" />}
                  </Label>
                  <Textarea
                    id="calendar-input"
                    placeholder={
                      isDemoMode
                        ? "Sample work schedule loaded (Mon-Fri 9AM-5PM)"
                        : "Paste your calendar events here..."
                    }
                    value={isDemoMode ? "Monday-Friday: 9:00 AM - 5:00 PM\nRegular office hours with lunch break" : ""}
                    className="min-h-[120px] bg-card/10 backdrop-blur-xl border-white/10 transition-all duration-300 focus:shadow-2xl focus:border-primary/30"
                    readOnly={isDemoMode}
                  />
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent backdrop-blur-xl border-white/10 hover:bg-primary/10 transition-all duration-300"
                      disabled={isDemoMode}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Upload .csv/.ics
                    </Button>
                    {isDemoMode && (
                      <Badge variant="secondary" className="text-xs">
                        Sample Data
                      </Badge>
                    )}
                  </div>
                </div>

                <div id="energy-profile" className="space-y-4">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <div className="p-1 rounded bg-accent/10">
                      <Zap className="h-4 w-4 text-accent" />
                    </div>
                    Energy Profile
                    {completedActions.has("energy-profile") && <CheckCircle className="h-4 w-4 text-green-500" />}
                  </Label>
                  <Select value={selectedDay} onValueChange={setSelectedDay}>
                    <SelectTrigger className="bg-card/10 backdrop-blur-xl border-white/10 transition-all duration-300 hover:border-primary/30">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {days.map((day) => (
                        <SelectItem key={day} value={day.toLowerCase()}>
                          {day}
                          {isDemoMode && energyLevels[`${day.toLowerCase()}-9:00`] && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              Sample
                            </Badge>
                          )}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="space-y-3 h-64 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-accent/30 scrollbar-track-transparent">
                    {timeSlots.map((time) => {
                      const slotKey = `${selectedDay}-${time}`
                      return (
                        <div
                          key={time}
                          className="flex items-center gap-3 text-sm p-2 rounded-lg hover:bg-accent/5 transition-colors duration-200"
                        >
                          <span className="w-12 text-muted-foreground font-mono">{time}</span>
                          <Slider
                            value={[energyLevels[slotKey] || 50]}
                            onValueChange={(value) => {
                              setEnergyLevels((prev) => ({
                                ...prev,
                                [slotKey]: value[0],
                              }))
                              if (!isDemoMode) triggerSuccess("energy-profile")
                            }}
                            max={100}
                            step={10}
                            className="flex-1"
                            disabled={isDemoMode}
                          />
                          <Select
                            value={energyTypes[slotKey] || "Task-Oriented"}
                            onValueChange={(value) => {
                              setEnergyTypes((prev) => ({
                                ...prev,
                                [slotKey]: value,
                              }))
                              if (!isDemoMode) triggerSuccess("energy-profile")
                            }}
                            disabled={isDemoMode}
                          >
                            <SelectTrigger className="w-32 h-8 bg-card/10 backdrop-blur-xl border-white/10 transition-all duration-200 hover:border-accent/30">
                              <SelectValue placeholder="Type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Creative">Creative</SelectItem>
                              <SelectItem value="Task-Oriented">Task-Oriented</SelectItem>
                              <SelectItem value="Low-Energy">Low-Energy</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )
                    })}
                  </div>
                </div>

                <div id="business-tasks" className="space-y-4">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <div className="p-1 rounded bg-primary/10">
                      <Target className="h-4 w-4 text-primary" />
                    </div>
                    Business Tasks
                    {completedActions.has("business-tasks") && <CheckCircle className="h-4 w-4 text-green-500" />}
                  </Label>
                  <div className="space-y-3">
                    {businessTasks.map((task) => (
                      <div
                        key={task.id}
                        className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-xl p-4 space-y-3 transition-all duration-300 hover:shadow-lg hover:border-primary/20"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm">{task.name}</span>
                          <div className="flex items-center gap-2">
                            <Badge
                              variant={task.priority === "High" ? "default" : "secondary"}
                              className="transition-colors duration-200"
                            >
                              {task.priority}
                            </Badge>
                            {isDemoMode && (
                              <Badge variant="outline" className="text-xs">
                                Sample
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{task.duration}h</span>
                          </div>
                          <span className="w-1 h-1 bg-muted-foreground rounded-full"></span>
                          <span>{task.energy}</span>
                        </div>
                        {scheduledTasks[task.id] && (
                          <div className="text-xs text-green-500 flex items-center gap-1 animate-pulse">
                            <CheckCircle className="w-3 h-3" />
                            Scheduled
                          </div>
                        )}
                      </div>
                    ))}
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full bg-transparent backdrop-blur-xl border-white/10 hover:bg-primary/10 transition-all duration-300 group"
                      onClick={() => triggerSuccess("business-tasks")}
                    >
                      <Plus className="mr-2 h-4 w-4 group-hover:rotate-90 transition-transform duration-300" />
                      {isDemoMode ? "Add Custom Task (Demo)" : "Add Custom Task"}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Center Area - Weekly Planning (45%) */}
          <div className="lg:col-span-5">
            <Card id="calendar-view" className="bg-card/80 backdrop-blur-xl border-white/10 p-6 h-full">
              <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-accent/10 shadow-lg shadow-accent/20">
                    <Calendar className="h-5 w-5 text-accent" />
                  </div>
                  <h2 className="text-xl font-semibold">Your Optimized Week</h2>
                </div>
                <Button
                  id="auto-optimize"
                  onClick={optimizeSchedule}
                  size="sm"
                  className="bg-gradient-to-r from-primary to-accent text-white hover:shadow-lg transition-all duration-300 relative"
                >
                  <Brain className="mr-2 h-4 w-4" />
                  Auto-Optimize
                  {completedActions.has("optimize") && (
                    <div className="absolute -top-1 -right-1">
                      <CheckCircle className="h-4 w-4 text-green-400 bg-background rounded-full" />
                    </div>
                  )}
                </Button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-8 gap-2 text-sm">
                  <div className="font-medium text-muted-foreground p-2">Time</div>
                  {days.map((day) => (
                    <div key={day} className="font-medium text-center text-muted-foreground p-2">
                      {day.slice(0, 3)}
                    </div>
                  ))}
                </div>

                <div className="space-y-1 h-96 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-accent/30 scrollbar-track-transparent">
                  {timeSlots.map((time) => (
                    <div key={time} className="grid grid-cols-8 gap-2">
                      <div className="text-xs text-muted-foreground py-2 px-2 font-mono">{time}</div>
                      {days.map((day) => {
                        const slotKey = `${day.toLowerCase()}-${time}`
                        const scheduledTask = Object.entries(scheduledTasks).find(([_, slot]) => slot === slotKey)?.[0]
                        const task = scheduledTask ? businessTasks.find((t) => t.id === scheduledTask) : null

                        return (
                          <div
                            key={`${day}-${time}`}
                            className={`h-10 border border-border/50 rounded-lg cursor-pointer transition-all duration-200 relative ${getEnergyHeatmapColor(day, time)} hover:border-accent/40`}
                            title={`Energy: ${energyLevels[slotKey] || 50}%`}
                          >
                            {task && (
                              <div className="absolute inset-0 bg-primary/60 rounded-lg flex items-center justify-center animate-pulse">
                                <span className="text-xs text-white font-medium truncate px-1">
                                  {task.name.slice(0, 8)}
                                </span>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 p-4 bg-card/10 backdrop-blur-xl border border-white/10 rounded-lg">
                <div className="flex flex-wrap gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-gray-400/30 rounded-full"></div>
                    <span>Work</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500/40 rounded-full"></div>
                    <span>High Energy (80%+)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-yellow-500/40 rounded-full"></div>
                    <span>Good Energy (60-80%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-500/40 rounded-full"></div>
                    <span>Medium Energy (40-60%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500/30 rounded-full"></div>
                    <span>Low Energy (less than 40%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary/60 rounded-full"></div>
                    <span>Scheduled</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Right Sidebar - Results (25%) */}
          <div className="lg:col-span-3 space-y-6">
            <Card id="recommendations" className="bg-card/80 backdrop-blur-xl border-white/10 p-6">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4 text-primary" />
                  <h3 className="font-medium">Smart Recommendations</h3>
                  {completedActions.has("recommendations") && <CheckCircle className="h-4 w-4 text-green-500" />}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setShowRecommendations(!showRecommendations)
                    if (!showRecommendations) triggerSuccess("recommendations")
                  }}
                  className="text-xs bg-gradient-to-r from-primary to-accent text-white hover:shadow-lg"
                >
                  {showRecommendations ? "Hide" : "Show"}
                </Button>
              </div>

              {showRecommendations && (
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {generateRecommendations.slice(0, 3).map((rec, index) => {
                    const task = businessTasks.find((t) => t.id === rec.taskId)
                    if (!task) return null

                    return (
                      <div key={index} className="bg-card/10 rounded-lg p-3 space-y-2 animate-fade-in">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{task.name}</span>
                          <Badge
                            variant="outline"
                            className="text-xs bg-gradient-to-r from-green-500/10 to-blue-500/10"
                          >
                            {rec.confidence}% match
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {rec.day} at {rec.time}
                        </div>
                        <div className="text-xs text-accent">{rec.reason}</div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full text-xs bg-gradient-to-r from-primary/10 to-accent/10 hover:from-primary/20 hover:to-accent/20 transition-all duration-300"
                          onClick={() => {
                            const slotKey = `${rec.day.toLowerCase()}-${rec.time}`
                            setScheduledTasks((prev) => ({ ...prev, [rec.taskId]: slotKey }))
                            triggerSuccess("schedule-task")
                          }}
                        >
                          <CheckCircle className="mr-2 h-3 w-3" />
                          Schedule Here
                        </Button>
                      </div>
                    )
                  })}
                  {generateRecommendations.length === 0 && (
                    <div className="text-sm text-muted-foreground text-center py-4">
                      {isDemoMode
                        ? "Click 'Auto-Optimize' to see recommendations in action!"
                        : "No recommendations available. Set your energy levels first."}
                    </div>
                  )}
                </div>
              )}
            </Card>

            {conflicts.length > 0 && (
              <Card className="bg-card/80 backdrop-blur-xl border-red-500/20 p-6 animate-shake">
                <div className="mb-4 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  <h3 className="font-medium text-red-500">Conflicts Detected</h3>
                </div>
                <div className="space-y-2">
                  {conflicts.map((conflict, index) => (
                    <div
                      key={index}
                      className="text-sm text-red-400 bg-red-500/10 rounded p-2 border border-red-500/20"
                    >
                      {conflict}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            <Card className="bg-card/80 backdrop-blur-xl border-white/10 p-6">
              <div className="mb-6 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-accent/10 shadow-lg shadow-accent/20">
                  <Target className="h-5 w-5 text-accent" />
                </div>
                <h2 className="text-xl font-semibold">Results</h2>
              </div>

              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-xl p-4 transition-all duration-300 hover:shadow-lg hover:border-primary/20">
                    <div className="text-sm text-muted-foreground mb-1">Weekly Focus Time</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                      {Object.keys(scheduledTasks).reduce((total, taskId) => {
                        const task = businessTasks.find((t) => t.id === taskId)
                        return total + (task?.duration || 0)
                      }, 0)}
                      h
                    </div>
                    {Object.keys(scheduledTasks).length > 0 && (
                      <div className="text-xs text-green-500 mt-1 flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        Tasks scheduled successfully!
                      </div>
                    )}
                  </div>

                  <div className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-xl p-4 transition-all duration-300 hover:shadow-lg hover:border-primary/20">
                    <div className="text-sm text-muted-foreground mb-1">Energy Match Score</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                      {generateRecommendations.length > 0 ? Math.round(generateRecommendations[0]?.confidence || 0) : 0}
                      %
                    </div>
                    {generateRecommendations.length > 0 && generateRecommendations[0]?.confidence > 80 && (
                      <div className="text-xs text-green-500 mt-1 flex items-center gap-1">
                        <Sparkles className="h-3 w-3" />
                        Excellent energy alignment!
                      </div>
                    )}
                  </div>

                  <div className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-xl p-4 transition-all duration-300 hover:shadow-lg hover:border-primary/20">
                    <div className="text-sm text-muted-foreground mb-1">Tasks Scheduled</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                      {Object.keys(scheduledTasks).length}/{businessTasks.length}
                    </div>
                    {Object.keys(scheduledTasks).length === businessTasks.length && (
                      <div className="text-xs text-green-500 mt-1 flex items-center gap-1 animate-pulse">
                        <CheckCircle className="h-3 w-3" />
                        All tasks scheduled! 🎉
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <Button className="w-full bg-gradient-to-r from-primary to-accent text-white font-medium py-3 hover:shadow-2xl transition-all duration-300 group">
                    <Download className="mr-2 h-4 w-4 group-hover:translate-y-0.5 transition-transform duration-200" />
                    Export Schedule
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent backdrop-blur-xl border-white/10 hover:bg-primary/10 transition-all duration-300"
                  >
                    Copy to Calendar
                  </Button>
                </div>

                <div className="bg-card/80 backdrop-blur-xl border border-white/10 rounded-xl p-4 space-y-3">
                  <h3 className="font-medium text-sm flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-accent" />
                    Quick Tips
                  </h3>
                  <ul className="text-xs text-muted-foreground space-y-2 leading-relaxed">
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 bg-accent rounded-full mt-2 flex-shrink-0"></span>
                      Schedule creative work during high-energy slots
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 bg-accent rounded-full mt-2 flex-shrink-0"></span>
                      Batch similar tasks together
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 bg-accent rounded-full mt-2 flex-shrink-0"></span>
                      Leave buffer time between work and side business
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
