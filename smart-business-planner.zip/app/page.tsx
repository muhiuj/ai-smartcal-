import { SmartBusinessPlanner } from "@/components/smart-business-planner"

export default function Home() {
  return <SmartBusinessPlanner />
}
